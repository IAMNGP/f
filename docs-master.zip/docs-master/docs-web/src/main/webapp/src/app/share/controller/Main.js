'use strict';

/**
 * Main controller.
 */
angular.module('share').controller('Main', function() {
});