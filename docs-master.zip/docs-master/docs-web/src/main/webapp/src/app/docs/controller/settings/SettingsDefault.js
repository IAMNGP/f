'use strict';

/**
 * Settings default page controller.
 */
angular.module('docs').controller('SettingsDefault', function($scope, Restangular) {
});