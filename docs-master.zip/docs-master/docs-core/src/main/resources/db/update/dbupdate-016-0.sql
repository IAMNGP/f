insert into T_CONFIG(CFG_ID_C, CFG_VALUE_C) values('DEFAULT_LANGUAGE', 'eng');
update T_CONFIG set CFG_VALUE_C = '16' where CFG_ID_C = 'DB_VERSION';
