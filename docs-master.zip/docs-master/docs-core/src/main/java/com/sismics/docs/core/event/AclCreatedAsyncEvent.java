package com.sismics.docs.core.event;

/**
 * ACL created event.
 *
 * @author bgamard
 */
public class AclCreatedAsyncEvent extends AclEvent {
}