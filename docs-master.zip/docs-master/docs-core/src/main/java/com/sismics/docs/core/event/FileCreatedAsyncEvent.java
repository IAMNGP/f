package com.sismics.docs.core.event;

/**
 * New file created event.
 *
 * @author bgamard
 */
public class FileCreatedAsyncEvent extends FileEvent {
}