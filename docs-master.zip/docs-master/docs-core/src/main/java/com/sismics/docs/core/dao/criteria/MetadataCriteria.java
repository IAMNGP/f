package com.sismics.docs.core.dao.criteria;

/**
 * Metadata criteria.
 *
 * @author bgamard 
 */
public class MetadataCriteria {
}
