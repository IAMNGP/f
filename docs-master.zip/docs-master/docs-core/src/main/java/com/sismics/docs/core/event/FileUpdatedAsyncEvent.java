package com.sismics.docs.core.event;

/**
 * New file created event.
 *
 * @author bgamard
 */
public class FileUpdatedAsyncEvent extends FileEvent {
}