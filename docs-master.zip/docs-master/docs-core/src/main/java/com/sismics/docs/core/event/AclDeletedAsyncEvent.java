package com.sismics.docs.core.event;

/**
 * ACL deleted event.
 *
 * @author bgamard
 */
public class AclDeletedAsyncEvent extends AclEvent {
}